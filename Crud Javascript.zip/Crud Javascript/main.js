let form = document.getElementById("form");
let input = document.getElementById("input");
let msg = document.getElementById("msg");
let posts = document.getElementById("posts");

form.addEventListener("submit", (e) => {
  e.preventDefault();
  formValidation();
});

let formValidation = () => {
  if (input.value === "") {
    msg.innerHTML = "Post cannot be blank";
    //   console.log("failure");
  } else {
    msg.innerHTML = "";
    //   console.log("successs");
    acceptData();
  }
};

//

let data = [];

let acceptData = () => {
  data.push(input.value);
  localStorage.setItem("Newdata", JSON.stringify(data))
  // console.log(data);
  createPost();
};

//post

let createPost = () => {
  posts.innerHTML += `
    <div>
      <p>${data[data.length-1]}</p>
      <span class="options">
        <i onClick="editPost(this)" class="fas fa-edit"></i>
        <i onClick="deletePost(this)" class="fas fa-trash-alt"></i>
      </span>
    </div>
    `;
  input.value = "";
};

//delete
let deletePost = (e) => {
  let postindex = e.parentElement.parentElement.remove();
  data.splice(postindex, 1);
  localStorage.setItem("Newdata", JSON.stringify(data))
};

//edit
let editPost = (e) => {
  input.value = e.parentElement.previousElementSibling.innerHTML;
  e.parentElement.parentElement.remove();
  deletePost(e);
};